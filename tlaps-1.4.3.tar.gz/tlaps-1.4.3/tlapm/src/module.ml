(*
 * Copyright (C) 2011  INRIA and Microsoft Corporation
 *)

Revision.f "$Rev: 32860 $";;

module T = M_t;;
module Fmt = M_fmt;;
module Gen = M_gen;;
module Elab = M_elab;;
module Standard = M_standard;;
module Flatten = M_flatten;;
module Dep = M_dep;;
module Parser = M_parser;;
module Save = M_save;;
module Globalness = M_globalness;;
