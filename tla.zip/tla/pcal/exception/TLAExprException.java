package pcal.exception;

/**
 * @author Simon Zambrovski
 * @version $Id$
 */
public class TLAExprException extends UnrecoverableException
{

    /**
     * @param message
     */
    public TLAExprException(String message)
    {
        super(message);
    }

}
