package pcal.exception;

/**
 * @author Simon Zambrovski
 * @version $Id$
 */
public class TLCTranslationException extends UnrecoverableException
{
    public TLCTranslationException(String message)
    {
        super(message);
    }
}
