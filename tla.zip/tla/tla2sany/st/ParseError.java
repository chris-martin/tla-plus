// Copyright (c) 2003 Compaq Corporation.  All rights reserved.
package tla2sany.st;


public interface ParseError  {

  public String reportedError();
  public String defaultError() ;
}

