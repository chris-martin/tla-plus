// Copyright (c) 2003 Compaq Corporation.  All rights reserved.
package tla2sany.explorer;

public class ExplorerQuitException extends Exception {
}
